using UnityEngine;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour
{
    [SerializeField] AudioClip bounceSFX;
    [SerializeField] AudioClip[] collectSFX;

    [SerializeField] AudioClip hamsterHitSFX;
    [SerializeField] AudioClip rewardSFX;
    [SerializeField] AudioClip accelerateSFX;

    [Header("Hit Sounds")]
    [SerializeField] AudioClip ballImpactSFX;
    [SerializeField] AudioClip hamsterFallSFX;
    [SerializeField] AudioClip splashingSFX;

    [Header("Bonus Stage Sounds")]
    [SerializeField] AudioClip puzzleSolvedSFX;

    [Range(0.0f, 1.0f)]
    [SerializeField] float minCollectVolume = 0.5f;

    [Range(0.0f, 1.0f)]
    [SerializeField] float maxCollectVolume = 0.6f;

    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioSource fullVolumeAS;


    public void PlayBounceSFX()
    {
        PlaySFX(bounceSFX);
    }

    public void PlayCollectSFX()
    {
        float volume = Random.Range(minCollectVolume, maxCollectVolume);
        float pitch = Random.Range(.9f, 1.5f);

        int index = Random.Range(0, collectSFX.Length);
        PlaySFX(collectSFX[index], 1, pitch);
    }

    bool playFallNext = true;

    public void PlayDeathSFX()
    {
        if (playFallNext)
        {
            fullVolumeAS.PlayOneShot(hamsterFallSFX, 1.0f);
        }
        else
        {
            PlaySFX(hamsterHitSFX, 0.3f);
        }

        // Toggle for other sound
        playFallNext = !playFallNext;
    }

    public void PlayRewardSFX()
    {
        PlaySFX(rewardSFX, 0.8f);
    }

    public void PlayAccelerateSFX()
    {
        PlaySFX(accelerateSFX, 0.7f);
    }

    public void PlayBallImpactSFX()
    {
        PlaySFX(ballImpactSFX, 1f);
    }

    public void PlayHamsterSplashSFX()
    {
        PlaySFX(splashingSFX, 0.4f);
    }

    public void PlayPuzzleSoundSFX()
    {
        PlaySFX(puzzleSolvedSFX, 0.7f);
    }

    void PlaySFX(AudioClip clip)
    {
        audioSource.PlayOneShot(clip);
    }

    void PlaySFX(AudioClip clip, float volume)
    {
        audioSource.PlayOneShot(clip, volume);
    }

    void PlaySFX(AudioClip clip, float volume, float pitch)
    {
        GameObject tempAudio = new GameObject("TempAudio");
        AudioSource tempSource = tempAudio.AddComponent<AudioSource>();

        tempSource.clip = clip;
        tempSource.volume = volume;
        tempSource.pitch = pitch;
        tempSource.PlayOneShot(clip);

        Destroy(tempAudio, clip.length);
    }
}
