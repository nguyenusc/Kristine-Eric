using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Cinemachine;
using System;
using EasyTextEffects;

public class EndSceneManager : MonoBehaviour
{
    PlayerMovement playerMovement;
    FogLerpController fogController;
    CinemachineDollyCart playerSpline;
    AudioManager audioManager;

    [Header("UI Fields")]
    [SerializeField] GameObject winPanel;
    [SerializeField] GameObject slider;
    [SerializeField] TextMeshProUGUI bonusStageText;

    [Header("Camera Fields")]
    [SerializeField] CinemachineVirtualCamera overheadCamera;
    [SerializeField] CinemachineVirtualCamera bigIceCreamCamera;
    [SerializeField] CinemachineVirtualCamera defaultCamera;


    [Header("Ice Cream Fields")]
    [SerializeField] GameObject iceCreamPrefab;
    [SerializeField] Transform spawnPoint;
    [SerializeField] Transform iceCreamTargetPosition;

    [Header("Countup Text Fields")]
    [SerializeField] TextMeshProUGUI finalScoreText;
    [SerializeField] float durationToTotal;

    bool hasSpawnedIceCream;

    bool hasWaterLowered;

    bool hasResetScene;

    bool soundHasPlayed;

    bool hasBonusStage;

    const float FOG_START = 418f;
    const float FOG_END = 1000f;

    private void Start()
    {
        playerMovement = FindObjectOfType<PlayerMovement>();
        fogController = FindObjectOfType<FogLerpController>();
        playerSpline = FindObjectOfType<CinemachineDollyCart>();
        audioManager = FindObjectOfType<AudioManager>();
    }

    void ShowEndPanel()
    {
        StartCoroutine(EndCutsceneSequence());
    }

    IEnumerator EndCutsceneSequence()
    {
        // Hide slider, show win panel
        slider.SetActive(false);
        winPanel.gameObject.SetActive(true);

        yield return new WaitForSeconds(3f);

        // Spawn ice cream and switch camera
        if (!hasSpawnedIceCream)
        {
            playerMovement.SetCameraPriority(bigIceCreamCamera);

            GameObject iceCream = Instantiate(iceCreamPrefab, spawnPoint.position, Quaternion.identity);
            iceCream.transform.localScale = Vector3.one * 0.1f;

            GrowAndMove growScript = iceCream.GetComponent<GrowAndMove>();
            Vector3 finalScale = new Vector3(25f, 17.6f, 23.7f);
            growScript.StartGrow(spawnPoint.position, iceCreamTargetPosition.position, finalScale, 2f);

            hasSpawnedIceCream = true;
        }

        yield return new WaitForSeconds(3f);

        // Switch to overhead cam
        playerMovement.SetCameraPriority(overheadCamera);
        winPanel.gameObject.SetActive(false);

        // Wait before lowering water
        yield return new WaitForSeconds(2.85f);

        // Lower water and lessen fog while doing so
        if (!hasWaterLowered)
        {
            LowerWater();
            fogController.LerpFogEnd(FOG_END);
            hasWaterLowered = true;
        }

        // Wait and play "puzzle solved jingle" before transitioning back to player
        yield return new WaitForSeconds(3f);
        if (!soundHasPlayed)
        {
            audioManager.PlayPuzzleSoundSFX();
            soundHasPlayed = true;
        }

        yield return new WaitForSeconds(1f);


        // Reset fog to its original value, set player to position beyond ice cream,
        // and camera to default player camera
        if (!hasResetScene)
        {
            playerSpline.enabled = true;

            fogController.LerpFogEnd(FOG_START);
            playerMovement.SetDefaultCamera();

            hasResetScene = true;
        }

        yield return new WaitForSeconds(2.3f);

        if (!hasBonusStage)
        {
            bonusStageText.gameObject.SetActive(true);
            playerMovement.BonusStageEffects();
            slider.SetActive(true);

            yield return new WaitForSeconds(2.5f);

            bonusStageText.gameObject.SetActive(false);

            hasBonusStage = true;
        }
    }



    public static event Action OnLowerWater;
    public static void LowerWater()
    {
        OnLowerWater?.Invoke();
    }

    public void CountUpTo(int targetNumber)
    {
        StartCoroutine(CountUpCoroutine(targetNumber, durationToTotal));
    }

    IEnumerator CountUpCoroutine(int target, float duration)
    {
        float elapsed = 0f;
        int current = 0;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            current = Mathf.RoundToInt(Mathf.Lerp(0, target, t));
            finalScoreText.text = current.ToString();
            yield return null;
        }

        // To make sure final number is hit
        finalScoreText.text = target.ToString();
    }

    private void OnEnable()
    {
        PlayerMovement.OnEndGame += ShowEndPanel;
    }
    private void OnDisable()
    {
        PlayerMovement.OnEndGame -= ShowEndPanel;
    }

}
